import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmation-dailog',
  templateUrl: './confirmation-dailog.component.html',
  styleUrls: ['./confirmation-dailog.component.scss']
})
export class ConfirmationDailogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
