import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmationDailogComponent } from './confirmation-dailog.component';

describe('ConfirmationDailogComponent', () => {
  let component: ConfirmationDailogComponent;
  let fixture: ComponentFixture<ConfirmationDailogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmationDailogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationDailogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });


});
